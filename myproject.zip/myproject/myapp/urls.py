from django.urls import path
from .views import home, register_record

urlpatterns = [
    path('', home, name='home'),
    path('register/', register_record, name='register_record'),
]